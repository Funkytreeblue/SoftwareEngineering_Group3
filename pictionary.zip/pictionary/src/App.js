import './App.scss'
import React, { useState } from 'react'
import { getPageComponent, PAGES } from './pages/Pages'

export default ({}) => {
    const [navState, setNavState] = useState({ pageId: PAGES[0].pageId });

    const navigator = {
        goToPage: (pageId, params) => setNavState({ pageId, params })
    }

    return React.createElement(getPageComponent(navState.pageId), {
        navigator, ...navState.params
    });
}
import React from 'react'
import BackBtn from '../../components/BackBtn';
import LevelBlock from '../../components/level-block/LevelBlock';
import Slider, { PaginationDots } from '../../components/slider/Slider';
import SelectLevelTitle from '../../images/SelectLevelTitle.png';
import { LEVELS } from '../../levels/Levels';

import './LevelSelectorPage.scss';

class LevelSelectorPage extends React.Component {

    state = {
        levelIndex: this.getFocusedLevelIndex()
    }

    goBack() {
        this.props.navigator.goToPage("home-page");
    }

    getFocusedLevelIndex() {
        const fromLevelId = this.props.fromLevelId;
        if (fromLevelId) {
            for (let i = 0; i < LEVELS.length; i++) {
                const level = LEVELS[i];
                if (level.levelId == fromLevelId) {
                    return i;   
                }
            }
        }
    }

    render() {
        return (
            <div className="page-root">
                <div className="top-left-layout">
                    <BackBtn onClick={this.goBack.bind(this)} />
                </div>

                <div className="level-select-top-bar">
                    <img className="level-select-title" src={SelectLevelTitle} />
                </div>

                <div className="level-select-root-area">
                    <div className="level-select-area">
                        <Slider defaultIndex={this.state.levelIndex} onIndexChanged={levelIndex => this.setState({ levelIndex })}>
                            {LEVELS.map(level => <LevelBlock key={`level-${level.levelId}`} title={level.name} img={level.image} 
                            onClick={() => this.props.navigator.goToPage("gameplay-page", { levelId: level.levelId })} />)}
                        </Slider>
                    </div>
                </div>

                <div className="level-select-bottom-bar">
                    <PaginationDots selectedIndex={this.state.levelIndex} count={LEVELS.length} />
                </div>
            </div>
        )
    }

}

export default LevelSelectorPage;
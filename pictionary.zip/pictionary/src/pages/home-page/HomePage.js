import React from 'react'
import IconBtn from '../../components/IconBtn'

import PlayBtnIcon from '../../images/PlayBtnIcon.png';
import Logo from '../../images/Logo.png';

import LoginBtn from '../../components/LoginBtn';
import LeaderBoardBtn from '../../components/LeaderBoardBtn';

export default ({navigator}) => (
    <div className="page-root" style={{display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column'}}>
        <img src={Logo} style={{height: 125, width: '100%', objectFit: 'contain', objectPosition: 'center', marginTop: 50}} />
        <div style={{flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center',}}>
            <IconBtn icon={PlayBtnIcon} style={{width: 150, height: 150}} onClick={() => navigator.goToPage("level-selector-page")} />
        </div>

        <div >
            <LeaderBoardBtn onClick={() => window.location.reload()} />
        </div>
        <div className="top-right-layout">
            <LoginBtn onClick={() => window.location.reload()} />
        </div>
    </div>
)
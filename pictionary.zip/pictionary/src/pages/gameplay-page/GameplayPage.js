import React from 'react';
import BackBtn from '../../components/BackBtn';
import SkipBtn from '../../components/SkipBtn';
import AudioIcon from '../../images/AudioIcon.png'

import './GameplayPage.scss';
import IconBtn from '../../components/IconBtn';
import TriesLeftIndicator from '../../components/tries-left-indicator/TriesLeftIndicator';
import WordImageBlock from '../../components/word-image-block/WordImageBlock';
import { getLevel, LEVELS } from '../../levels/Levels';
import Modal from '../../components/modal/Modal';

import Confetti from 'react-confetti'
import StarRating from '../../components/StarRating';

//Calculating stars based on gameplay
let correctWordCounter = 0;
let wordAmount = 13;
let starAmount = 0;

let calcScore = (wordsCorrect, amountOfWords) => {
    const percentageCorrect = (wordsCorrect / amountOfWords) * 100;
    let amountOfStars = 0;
    if (percentageCorrect > 50 && percentageCorrect <= 100) {
        amountOfStars = 3;
    } else if (percentageCorrect <= 50 && percentageCorrect > 25) {
        amountOfStars = 2;
    } else if (percentageCorrect <= 25 && percentageCorrect > 0) {
        amountOfStars = 1;
    } else if (wordsCorrect === 0) {
        amountOfStars = 0;
    }

    return { amountOfStars };
};


class GameplayPage extends React.Component {

    state = {
        wordIndex: 0,
        triesLeft: 3,
        score: 0,
        highScore: 0,

        isShowingMessage: false,
        messageTitle: undefined,
        messageSubtitle: undefined,
        messageRedMode: false,

        gameWon: false
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.isShowingMessage && !this.state.isShowingMessage && this.showingMessageDoneListener) {
            this.showingMessageDoneListener();
        }
    }

    showMessage(title, subtitle, redMode, onDone) {
        this.showingMessageDoneListener = onDone;
        this.setState({ isShowingMessage: true, messageTitle: title, messageSubtitle: subtitle, messageRedMode: redMode })
    }

    componentDidMount() {
        this.playCurrentWordAudio();
    }

    componentWillUnmount() {
        this.showingMessageDoneListener = undefined;
    }

    playCurrentWordAudio() {
        new Audio(this.getCurrentLevel()[this.state.wordIndex].audio).play();
    }

    onGameWon() {
        if (localStorage.getItem("highScore") === null) {
            localStorage.setItem("highScore", "0");
        }
        if (this.state.score > parseInt(localStorage.getItem("highScore"))) {
            localStorage.setItem("highScore", this.state.score.toString());
            this.setState((prevState) => ({ highScore: this.state.score }));
        } else {
            this.setState((prevState) => ({ highScore: parseInt(localStorage.getItem("highScore")) }));
        }
        this.setState({ gameWon: true })
        this.showMessage("Congratulations!", "You have won!", false);
        // localStorage.setItem(
        //     "star-amount",
        //     "2"
        //     //   JSON.stringify(calcScore(correctWordCounter, wordAmount))
        //   );
    }

    onOutOfTries() {
        this.showMessage("Incorrect choice!", "The correct answer is image " + this.getCorrectWordIndex(), true, () => {
            this.setState(prevState => ({ wordIndex: prevState.wordIndex + 1 }), this.playCurrentWordAudio.bind(this))
            this.setState(prevState => ({ triesLeft: 3 }))
        });
    }

    getCorrectWordIndex() {
        for (let i = 0; i < this.getCurrentLevel()[this.state.wordIndex].options.length; i++) {
            if (this.getCurrentLevel()[this.state.wordIndex].options[i].correct) {
                return i + 1;
            }
        }
        return '';
    }

    onPictureSelected(word) {
        if (word.correct) {
            this.setState((prevState) => ({ score: prevState.score + 1 }));
            this.showMessage("Good job!", "Correct choice", false, () => {
                if (this.state.wordIndex == this.getCurrentLevel().length - 1) {
                    this.onGameWon();
                } else {
                    this.setState(prevState => ({ wordIndex: prevState.wordIndex + 1 }), this.playCurrentWordAudio.bind(this))
                }
            })
        } else {
            this.setState(prevState => ({ triesLeft: prevState.triesLeft - 1 }))

            if (this.state.triesLeft > 1) {
                this.showMessage("Incorrect choice!", `You have ${this.state.triesLeft - 1} ${this.state.triesLeft - 1 == 1 ? 'try' : 'tries'} left`, true)
            }
            else {
                if (this.state.wordIndex == this.getCurrentLevel().length - 1) {
                    this.onOutOfTries();
                    this.goBack();
                }
                else {
                    this.onOutOfTries();
                }
            }
        }
    }

    onSkipSelected() {
        if (this.state.wordIndex == this.getCurrentLevel().length - 1) {
            this.onGameWon();
        } else {
            this.setState(
                (prevState) => ({ wordIndex: prevState.wordIndex + 1 }),
                this.playCurrentWordAudio.bind(this)
            );
        }
    }

    getCurrentLevel() {
        return getLevel(this.props.levelId).content;
    }

    getCurrentWord() {
        return this.getCurrentLevel()[this.state.wordIndex].word;
    }

    getCurrentOptions() {
        return this.getCurrentLevel()[this.state.wordIndex].options;
    }

    goBack() {
        this.props.navigator.goToPage("level-selector-page", { fromLevelId: this.props.levelId });
    }

    goToLevelSelect() {
        this.props.navigator.goToPage("level-selector-page", { fromLevelId: this.props.levelId });
    }

    replayLevel() {
        this.setState(
            {
                wordIndex: 0,
                triesLeft: 3,
                score: 0,
                highScore: 0,

                isShowingMessage: false,
                messageTitle: undefined,
                messageSubtitle: undefined,
                messageRedMode: false,

                gameWon: false
            },
            this.playCurrentWordAudio.bind(this)
            );
        
    }

    getNextLevelIndex() {
        for(var i = 0; i < LEVELS.length; i++) {
            if(LEVELS[i].levelId == this.props.levelId) {
                return i + 1;
            }
        }
    }

    isNextLevel() {
        if(LEVELS.length == this.getNextLevelIndex()) {
            return false;
        }
        else {
            return true;
        }
    }

    goToNextLevel() {
        this.setState(
            {
                wordIndex: 0,
                triesLeft: 3,
                score: 0,
                highScore: 0,

                isShowingMessage: false,
                messageTitle: undefined,
                messageSubtitle: undefined,
                messageRedMode: false,

                gameWon: false
            },        
            this.props.navigator.goToPage("gameplay-page", { levelId: LEVELS[this.getNextLevelIndex()].levelId })
        );
    }

    render() {
        return (
            <div className="page-root">
                <div className="top-left-layout">
                    <BackBtn onClick={this.goBack.bind(this)} />
                </div>

                <div className="gameplay-top-bar">
                    <h1 className="gameplay-word-title">{this.getCurrentWord()}</h1>
                </div>

                <div className="top-right-layout" style={{ marginRight: 50 }}>
                    <IconBtn icon={AudioIcon} onClick={this.playCurrentWordAudio.bind(this)} />
                </div>

                <div className="gameplay-root-area">
                    <div className="gameplay-area">
                        {this.getCurrentOptions().map((option, index) => (
                            <WordImageBlock key={this.getCurrentWord + "-option-" + index} image={option.image} onClick={() => this.onPictureSelected(option)} />
                        ))}
                    </div>
                </div>

                <div className="bottom-left-layout" style={{ marginLeft: 25 }}>
                    <TriesLeftIndicator triesLeft={this.state.triesLeft} />
                </div>

                <div className="bottom-right-layout" style={{ display: 'flex', alignItems: 'center', gap: 25 }}>
                    <p className="word-count">Word {this.state.wordIndex + 1} of {this.getCurrentLevel().length}</p>
                    <SkipBtn onClick={() => this.onSkipSelected()} />
                </div>

                <Modal key="message-modal" open={this.state.isShowingMessage} onClose={() => { this.setState({ isShowingMessage: false }) }}
                    title={this.state.messageTitle} subtitle={this.state.messageSubtitle} redMode={this.state.messageRedMode} />

                <Modal key="won-modal" open={this.state.gameWon} onClose={this.goBack.bind(this)}
                onLevelSelect={this.goToLevelSelect.bind(this)} onReplay={this.replayLevel.bind(this)}
                onNextLevel={this.goToNextLevel.bind(this)} hideControls={(this.state.gameWon ? true : false)}
                isNextLevel={this.isNextLevel()}>
                    <div className="winning-message-layout">
                        <h1>{'Congratulations'.toUpperCase()}!</h1>
                        <h2 className="success-message">You've won!</h2>

                        <div style={{height: 15}} />

                        <StarRating
                        wordsCorrect={correctWordCounter}
                        amountOfWords={wordAmount}
                        >
                        {" "}
                        </StarRating>

                        <div style={{height: 25}} />
                        <h3 className="current-score">
                            Your current score is {this.state.score}/
                            {this.getCurrentLevel().length}
                        </h3>
                        <h3 className="highscore-message">
                            Your highscore is {this.state.highScore}
                        </h3>
                    </div>
                </Modal>

                {this.state.gameWon && <Confetti style={{ zIndex: 1001 }} />}
            </div>
        )
    }

}


export default GameplayPage;

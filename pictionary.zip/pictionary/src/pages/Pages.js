import GameplayPage from "./gameplay-page/GameplayPage";
import HomePage from "./home-page/HomePage";
import LevelSelectorPage from "./level-selector-page/LevelSelectorPage";

export const PAGES = [
    {
        pageId: "home-page",
        component: HomePage
    }, 
    {
        pageId: "level-selector-page",
        component: LevelSelectorPage
    }, 
    {
        pageId: "gameplay-page",
        component: GameplayPage
    }
];

export const getPageComponent = pageId => {
    for (const page of PAGES) {
        if (page.pageId == pageId) {
            return page.component;
        }
    }
}
//images
import Apple from "../images/word-images/Apple.jpg";
import Bannock from "../images/word-images/Bannock.jpeg";
import Cookies from "../images/word-images/Cookies.jpg";
import Meat from "../images/word-images/Meat.png";
import Milk from "../images/word-images/Milk.jpg";
import Potato from "../images/word-images/Potato.jpg";
import Salt from "../images/word-images/Salt.jpg";
import Water from "../images/word-images/Water.jpg";

//audios
import AppleAudio from "../audios/Apple.mp3";
import BannockAudio from "../audios/Bannock.mp3";
import CookiesAudio from "../audios/Cookies.mp3";
import MeatAudio from "../audios/Meat.mp3";
import MilkAudio from "../audios/Milk.mp3";
import PotatoAudio from "../audios/Potato.mp3";
import SaltAudio from "../audios/Salt.mp3";
import WaterAudio from "../audios/Water.mp3";

export default [
    {
        word: "Wenju'su'n",
        audio: AppleAudio,
        options: [
            {
                image: Apple,
                correct: true
            },
            {
                image: Water
            },
            {
                image: Potato              
            },
        ],
    },

    {
        word: "Lusknikn",
        audio: BannockAudio,
        options: [
            {
                image: Meat,
                correct: true
            },
            {
                image: Bannock,
                correct: true
            },
            {
                image: Salt              
            },
        ],
    },

    {
        word: "Kakknawey",
        audio: CookiesAudio,
        options: [
            {
                image: Cookies,
                correct: true
            },
            {
                image: Apple
            },
            {
                image: Potato              
            },
        ],
    },

    {
        word: "Wius",
        audio: MeatAudio,
        options: [
            {
                image: Cookies
            },
            {
                image: Water
            },
            {
                image: Meat,
                correct: true              
            },
        ],
    },

    {
        word: "Mlakej",
        audio: MilkAudio,
        options: [
            {
                image: Milk,
                correct: true
            },
            {
                image: Salt
            },
            {
                image: Potato              
            },
        ],
    },

    {
        word: "Tapatat",
        audio: PotatoAudio,
        options: [
            {
                image: Potato,
                correct: true
            },
            {
                image: Meat
            },
            {
                image: Bannock              
            },
        ],
    },

    {
        word: "Salawey",
        audio: SaltAudio,
        options: [
            {
                image: Milk
            },
            {
                image: Water
            },
            {
                image: Salt,
                correct: true              
            },
        ],
    },

    {
        word: "Samqwan",
        audio: WaterAudio,
        options: [
            {
                image: Apple
            },
            {
                image: Water,
                correct: true
            },
            {
                image: Meat              
            },
        ],
    }
];
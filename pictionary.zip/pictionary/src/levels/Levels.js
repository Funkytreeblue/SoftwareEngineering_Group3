//level content
import LevelOneContent from "./LevelOneContent";

//level images
import Animals from "../images/level-images/Animals.png";
import Placeholder from "../images/Placeholder.png";
import Numbers from "../images/level-images/Numbers.jpg";
import LevelFourContent from "./LevelFourContent";
import Food from "../images/level-images/Food.jpg";
import LevelTwoContent from "./LevelTwoContent";

export const LEVELS = [
    {
        levelId: 'animal-level',
        name: "Animals",
        image: Animals,
        content: LevelOneContent
    },
    {
        levelId: 'food-level',
        name: "Food",
        image: Food,
        content: LevelTwoContent
    },
    {
        levelId: "number-level",
        name: "Numbers",
        image: Numbers,
        content: LevelFourContent,
    },
];

export const getLevel = levelId => {
    for (const level of LEVELS) {
        if (level.levelId == levelId) {
            return level;
        }
    }
}
//images
import Whale from "../images/word-images/Whale.png";
import Lion from "../images/word-images/Lion.png";
import Bird from "../images/word-images/Bird.png";

import Ant from "../images/word-images/Ant.png";
import Bass from "../images/word-images/Bass.png";
import Bat from "../images/word-images/bat.png";
import Bear from "../images/word-images/Bear.png";
import Beaver from "../images/word-images/beaver.png";
import Bee from "../images/word-images/bee.png";
import Bullfrog from "../images/word-images/bullfrog.png";
import Butterfly from "../images/word-images/butterfly.png";
import Camel from "../images/word-images/camel.png";
import Chipmunk from "../images/word-images/chipmunk.png";
import Crab from "../images/word-images/crab.png";

//audios
import AntAudio from "../audios/Ant.mp3";
import BassAudio from "../audios/Bass.mp3";
import BatAudio from "../audios/Bat.mp3";
import BearAudio from "../audios/Bear.mp3";
import BeaverAudio from "../audios/Beaver.mp3";
import BeeAudio from "../audios/Bee.mp3";
import ButterflyAudio from "../audios/Butterfly.mp3";
import BullfrogAudio from "../audios/Bullfrog.mp3";
import CamelAudio from "../audios/Camel.mp3";
import ChipmunkAudio from "../audios/Chipmunk.mp3";
import CrabAudio from "../audios/Crab.mp3";
import LionAudio from "../audios/Lion.mp3";
import WhaleAudio from "../audios/Whale.mp3";

//level one

export default [
    {
        word: "Amu",
        audio: BeeAudio,
        options: [
            {
                image: Lion,
            },
            {
                image: Bass,
            },
            {
                image: Bee,
                correct: true,
            },
        ],
    },
    {
        word: "Muin",
        audio: BearAudio,
        options: [
            {
                image: Bird,
            },
            {
                image: Bat,
            },
            {
                image: Bear,
                correct: true,
            },
        ],
    },
    {
        word: "Na'jipuktaqnej",
        audio: BatAudio,
        options: [
            {
                image: Ant,
            },
            {
                image: Bass,
            },
            {
                image: Bat,
                correct: true,
            },
        ],
    },
    {
        word: "Kopit",
        audio: BeaverAudio,
        options: [
            {
                image: Bear,
            },
            {
                image: Beaver,
                correct: true,
            },
            {
                image: Bee,
            },
        ],
    },
    {
        word: "Aplekemu",
        audio: BullfrogAudio,
        options: [
            {
                image: Bird,
            },
            {
                image: Bullfrog,
                correct: true,
            },
            {
                image: Butterfly,
            },
        ],
    },
    {
        word: "Melkawlejit",
        audio: CamelAudio,
        options: [
            {
                image: Camel,
                correct: true,
            },
            {
                image: Chipmunk,
            },
            {
                image: Crab,
            },
        ],
    },
    {
        word: "Mimikej",
        audio: ButterflyAudio,
        options: [
            {
                image: Ant,
            },
            {
                image: Bear,
            },
            {
                image: Butterfly,
                correct: true,
            },
        ],
    },
    {
        word: "Ji'kaw",
        audio: BassAudio,
        options: [
            {
                image: Bass,
                correct: true,
            },
            {
                image: Crab,
            },
            {
                image: Bird,
            },
        ],
    },
    {
        word: "Petalu",
        audio: LionAudio,
        options: [
            {
                image: Lion,
                correct: true,
            },
            {
                image: Chipmunk,
            },
            {
                image: Beaver,
            },
        ],
    },
    {
        word: "Nmjinkej",
        audio: CrabAudio,
        options: [
            {
                image: Crab,
                correct: true,
            },
            {
                image: Whale,
            },
            {
                image: Ant,
            },
        ],
    },
    {
        word: "Kinikwejit",
        audio: AntAudio,
        options: [
            {
                image: Bear,
            },
            {
                image: Ant,
                correct: true,
            },
            {
                image: Bee,
            },
        ],
    },
    {
        word: "Apalpaqmej",
        audio: ChipmunkAudio,
        options: [
            {
                image: Chipmunk,
                correct: true,
            },
            {
                image: Beaver,
            },
            {
                image: Ant,
            },
        ],
    },
    {
        word: "Putup",
        audio: WhaleAudio,
        options: [
            {
                image: Bird,
            },
            {
                image: Butterfly,
            },
            {
                image: Whale,
                correct: true,
            },
        ],
    },
];

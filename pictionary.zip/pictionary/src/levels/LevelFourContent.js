//images
import One_Hundred_Eleven from "../images/word-images/111.jpg";
import One from "../images/word-images/1.jpg";
import Two_Hundred_Fifty from "../images/word-images/250.jpg";

import Seventy_Five from "../images/word-images/75.jpg";
import Three from "../images/word-images/3.jpg";
import Fifty from "../images/word-images/50.jpg";
import Ninety_Four from "../images/word-images/94.jpg";
import Two_Hundred from "../images/word-images/200.png";
import One_Hundred from "../images/word-images/100.jpg";
import One_Hundred_Twenty_Five from "../images/word-images/125.png";
import Five_Hundred from "../images/word-images/500.jpg";

//audios
import AntAudio from "../audios/Ant.mp3";
import BassAudio from "../audios/Bass.mp3";
import BatAudio from "../audios/Bat.mp3";
import BearAudio from "../audios/Bear.mp3";
import BeaverAudio from "../audios/Beaver.mp3";
import BeeAudio from "../audios/Bee.mp3";
import ButterflyAudio from "../audios/Butterfly.mp3";
import BullfrogAudio from "../audios/Bullfrog.mp3";
import CamelAudio from "../audios/Camel.mp3";
import ChipmunkAudio from "../audios/Chipmunk.mp3";
import CrabAudio from "../audios/Crab.mp3";
import LionAudio from "../audios/Lion.mp3";
import WhaleAudio from "../audios/Whale.mp3";

//level four

export default [
    {
        word: "nanisga'q",
        //audio: BeeAudio,
        options: [
            {
                image: One,
            },
            {
                image: One_Hundred_Twenty_Five,
            },
            {
                image: Fifty,
                correct: true,
            },
        ],
    },
    {
        word: "gasg'ptnnaqanipuna't",
        //audio: BearAudio,
        options: [
            {
                image: One_Hundred_Eleven,
            },
            {
                image: Ninety_Four,
            },
            {
                image: One_Hundred,
                correct: true,
            },
        ],
    },
    {
        word: "si'st",
        //audio: BatAudio,
        options: [
            {
                image: Seventy_Five,
            },
            {
                image: Three,
                correct: true,
            },
            {
                image: Ninety_Four,
            },
        ],
    },
    {
        word: "na’n kaskimtlnaqn",
        //audio: BeaverAudio,
        options: [
            {
                image: Two_Hundred,
            },
            {
                image: Five_Hundred,
                correct: true,
            },
            {
                image: One_Hundred,
            },
        ],
    },
];

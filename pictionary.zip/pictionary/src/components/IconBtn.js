import React from 'react'

export default ({icon, ...props}) => <img {...props} className={"icon-btn" + (props.className ? " " + props.className : "")} src={icon} />
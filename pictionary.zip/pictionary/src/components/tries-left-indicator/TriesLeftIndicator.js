import React from 'react'
import HeartIcon from '../../images/HeartIcon.png'

import './TriesLeftIndicator.scss'

export default ({triesLeft, ...props}) => (
    <div {...props} className="tries-left-indicator">
        <img className="heart-icon" src={HeartIcon} />
        <div className="heart-bar">
            {triesLeft} {triesLeft == 1 ? 'try' : 'tries'} left
        </div>
    </div>
)
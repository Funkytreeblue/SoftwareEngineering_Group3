import React from "react";
import PropTypes from "prop-types";

import ZeroStar from "../images/StarsZero.png";
import OneStar from "../images/StarsOne.png";
import TwoStar from "../images/StarsTwo.png";
import ThreeStar from "../images/StarsThree.png";

//amount of stars

let amountOfStars = 0;

const calcScore = (wordsCorrect, amountOfWords) => {
  const percentageCorrect = (wordsCorrect / amountOfWords) * 100;

  if (percentageCorrect > 50 && percentageCorrect <= 100) {
    amountOfStars = 3;
  } else if (percentageCorrect <= 50 && percentageCorrect > 25) {
    amountOfStars = 2;
  } else if (percentageCorrect <= 25 && percentageCorrect > 0) {
    amountOfStars = 1;
  } else if (wordsCorrect === 0) {
    amountOfStars = 0;
  }

  return { amountOfStars };
};

export default ({ wordsCorrect, amountOfWords, amountOfStars, mini }) => {
  const height = mini ? 60 : 100;

  if (amountOfStars) {
    if (amountOfStars === 3) {
      return (
        <img src={ThreeStar} style={{ objectFit: "contain", height: height }} />
      );
    } else if (amountOfStars === 2) {
      return (
        <img src={TwoStar} style={{ objectFit: "contain", height: height }} />
      );
    } else if (amountOfStars === 1) {
      return (
        <img src={OneStar} style={{ objectFit: "contain", height: height }} />
      );
    } else if (amountOfStars === 0) {
      return (
        <img src={ZeroStar} style={{ objectFit: "contain", height: height }} />
      );
    }
  } else {
    if (calcScore(wordsCorrect, amountOfWords).amountOfStars === 3) {
      return (
        <img src={ThreeStar} style={{ objectFit: "contain", height: height }} />
      );
    } else if (calcScore(wordsCorrect, amountOfWords).amountOfStars === 2) {
      return (
        <img src={TwoStar} style={{ objectFit: "contain", height: height }} />
      );
    } else if (calcScore(wordsCorrect, amountOfWords).amountOfStars === 1) {
      return (
        <img src={OneStar} style={{ objectFit: "contain", height: height }} />
      );
    } else if (calcScore(wordsCorrect, amountOfWords).amountOfStars === 0) {
      return (
        <img src={ZeroStar} style={{ objectFit: "contain", height: height }} />
      );
    }
  }
};

import React, { useRef, useState } from 'react'
import useSize from '../../hooks/useSize';
import ImageFrame from '../../images/ImageFrame.png'
import StarsTwo from '../../images/StarsTwo.png';
import StarsZero from '../../images/StarsZero.png';
import './LevelBlock.scss';
import { isSafari, isMobileSafari } from 'react-device-detect';
import StarRating from '../StarRating';

const FRAME_WIDTH = 532;
const FRAME_HEIGHT = 419;

const TOP_PADDING = 9;
const BOTTOM_PADDING = 57;
const SIDE_PADDING = 13;

const calcFrameSize = (layoutWidth, layoutHeight) => {
    const horizScale = layoutWidth / FRAME_WIDTH;
    const vertScale = layoutHeight / FRAME_HEIGHT;

    const scale = Math.min(horizScale, vertScale);

    const width = FRAME_WIDTH * scale;
    const height = FRAME_HEIGHT * scale;

    const paddingTop = TOP_PADDING * scale;
    const paddingBottom = BOTTOM_PADDING * scale;
    const paddingSide = SIDE_PADDING * scale;

    return { width, height, paddingTop, paddingBottom, paddingSide }
}

export default ({img, title, onClick}) => {
    const layoutRef = useRef();
    const size = useSize(layoutRef);
    const frameSize = calcFrameSize(size.width, size.height);

    const [hover, setHover] = useState(false);

    return (
        <div ref={layoutRef} className="level-block-layout">
            <img className="level-block-frame" src={ImageFrame} style={{width: frameSize.width + (hover ? 45 : 0), height: frameSize.height + (hover ? 45 : 0)}} />
            <div onClick={onClick} className="level-block-content" style={{width: 
                frameSize.width - (frameSize.paddingSide * 2), //+ (hover ? 45 : 0), 
                height: frameSize.height - frameSize.paddingTop - frameSize.paddingBottom + (hover ? 45 : 0), 
                marginTop: frameSize.paddingTop - frameSize.paddingBottom / ((isSafari || isMobileSafari) ? 2 : 1.25),
            }} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} >
                <div className="level-block-content-layout">
                    <img src={img} className="level-block-image" />
                    <div className="level-block-title-layout">
                        {/* <img src={StarsZero} style={{objectFit: 'contain', height: 60}} /> */}
                        <StarRating amountOfStars = {3} mini ></StarRating>
                        <p className="level-block-title-text">{title}</p>
                    </div>
                </div>
            </div>
        </div>
    )
}
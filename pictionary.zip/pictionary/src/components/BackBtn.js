import React from 'react'
import BackBtnIcon from '../images/BackBtnIcon.png'

export default (props) => (
    <div {...props} className="left-side-btn">
        <img src={BackBtnIcon} />
        <p>Back</p>
    </div>
)
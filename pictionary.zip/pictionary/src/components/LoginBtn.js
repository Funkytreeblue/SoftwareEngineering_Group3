import React from 'react'
import UserIcon from '../images/UserIcon.png'

export default (props) => (
    <div {...props} className="right-side-btn">
        <img src={UserIcon} />
        <p>Login</p>
    </div>
)
import React from 'react'
import WideButton from '../images/WideButton.png'

export default (props) => (
    <div {...props} className="center-btn" style={{position: 'relative'}}>
        <img src={WideButton}/>
        <div style={{position: 'absolute', top: `${(25/168)*100}%`, height: `${(75/168)*100}%`, display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
            <h2 style={{ }}>Leaderboard</h2>
        </div>
    </div>
)
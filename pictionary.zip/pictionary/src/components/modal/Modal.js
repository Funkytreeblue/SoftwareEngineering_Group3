import React from 'react'
import ReactDom from 'react-dom'
import './Modal.scss';


export default function Modal({ open, children, onClose, title, subtitle, redMode, hideControls, isNextLevel, onLevelSelect, onNextLevel, onReplay }) {
    if (!open) return null

    return ReactDom.createPortal(
        <div className={(redMode ? "red-mode " : "") + "modal-root-layout"} onClick={e => {
            if (e.currentTarget == e.target) {
                onClose();
            }
        }}>
            <div className="modal">
                {title && <h2>{title}</h2>}
                {subtitle && <p className="modal-subtitle">{subtitle}</p>}
                {children}
                
                {!hideControls && <div className="modal-primary-btn" onClick={onClose}>
                    <p>Okay</p>
                </div>}

                {hideControls && <div className="modal-level-select-btn" onClick={onLevelSelect}>
                    <p>Level Select</p>
                </div>}

                {hideControls && isNextLevel &&
                <div className="modal-next-level-btn" onClick={onNextLevel}>
                    <p>Next Level</p>
                </div>}

                {hideControls && <div className="modal-replay-btn" onClick={onReplay}>
                    <p>Replay</p>
                </div>}
            </div>
        </div>,
        document.getElementById('portal')
    )
}
import React, { useEffect, useState } from 'react'
import IconBtn from '../IconBtn';
import PreviousBtnIcon from '../../images/PreviousBtnIcon.png';
import NextBtnIcon from '../../images/NextBtnIcon.png';
import './Slider.scss';

export const PaginationDots = ({selectedIndex, count}) => {
    let dots = [];
    for (let i = 0; i < count; i++) {
        dots.push(<div className={selectedIndex == i ? "selected-pagination-dot" : "pagination-dot"} />)
        
    }

    return (
        <div className="pagination-dots-layout">
            {dots}
        </div>
    )
}

export default ({defaultIndex, onIndexChanged, children}) => {
    const [index, setIndex] = useState(defaultIndex ? defaultIndex : 0);
    
    const hasPrevious = index > 0;
    const hasNext = index < (children.length - 1);

    useEffect(() => onIndexChanged(index), [index]);

    return (
        <div className="slider-root">
            {hasPrevious ? <IconBtn icon={PreviousBtnIcon} onClick={() => setIndex(prevIndex => prevIndex - 1)} /> : <div className="slider-button-gap" />}
            <div className="slider-content">
                {children[index]}
            </div>
            {hasNext ? <IconBtn icon={NextBtnIcon} onClick={() => setIndex(prevIndex => prevIndex + 1)} /> : <div className="slider-button-gap" />}
        </div>
    )
}
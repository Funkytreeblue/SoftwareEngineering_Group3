import React from 'react'
import SkipBtnIcon from '../images/SkipBtnIcon.png'

export default (props) => (
    <div {...props} className="right-side-btn">
        <p>Skip</p>
        <img src={SkipBtnIcon} />
    </div>
)
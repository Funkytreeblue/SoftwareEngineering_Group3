import React, { useRef, useState } from 'react'
import useSize from '../../hooks/useSize';
import ImageFrame from '../../images/ImageFrame.png'
import './WordImageBlock.scss';
import { isSafari, isMobileSafari } from 'react-device-detect';

const FRAME_WIDTH = 532;
const FRAME_HEIGHT = 419;

const TOP_PADDING = 9;
const BOTTOM_PADDING = 57;
const SIDE_PADDING = 13;

const calcFrameSize = (layoutWidth, layoutHeight) => {
    const horizScale = layoutWidth / FRAME_WIDTH;
    const vertScale = layoutHeight / FRAME_HEIGHT;

    const scale = Math.min(horizScale, vertScale);

    const width = FRAME_WIDTH * scale;
    const height = FRAME_HEIGHT * scale;

    const paddingTop = TOP_PADDING * scale;
    const paddingBottom = BOTTOM_PADDING * scale;
    const paddingSide = SIDE_PADDING * scale;

    return { width, height, paddingTop, paddingBottom, paddingSide }
}

export default ({image, onClick}) => {
    const layoutRef = useRef();
    const size = useSize(layoutRef);
    const frameSize = calcFrameSize(size.width, size.height);

    const [hover, setHover] = useState(false);

    return (
        <div ref={layoutRef} className="word-image-block-layout">
            <img className="word-image-block-frame" src={ImageFrame} style={{width: frameSize.width + (hover ? 25 : 0), height: frameSize.height + (hover ? 25 : 0)}} />
            <img src={image} onClick={onClick} className="word-image-content" style={{width: 
                frameSize.width - (frameSize.paddingSide * 2) - (hover ? 25 : 0), 
                height: frameSize.height - frameSize.paddingTop - frameSize.paddingBottom - (hover ? 25 : 0), 
                marginTop: frameSize.paddingTop - frameSize.paddingBottom / ((isSafari || isMobileSafari) ? 2 : 1.25),
            }} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} />
        </div>
    )
}